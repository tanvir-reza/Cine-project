from django.contrib import admin
from .models import Info,Category,Movie

# Register your models here.
admin.site.register(Info)
admin.site.register(Category)
admin.site.register(Movie)
